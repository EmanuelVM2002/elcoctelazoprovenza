# Plan: QR de las mesas, seguridad de las mesas y login de la barra

Documento de trabajo (12/11/2026). Está en `qr-mesas/`, que **no se sube a GitHub ni se publica** (lo excluyen `.gitignore` y `.assetsignore`), porque describe puntos débiles.

---

## 0. Lo que encontré hoy (verificado en el código y en GitHub)

| # | Hallazgo | Gravedad |
|---|---|---|
| 1 | El repositorio `elcoctelazoprovenza` es **público**, y `worker/index.js` trae escritos el usuario y la contraseña de la barra, la llave de las sesiones y la llave de los QR (constante `EJEMPLO`). Cualquiera que abra GitHub puede **entrar al panel de la barra** y **fabricar el QR válido de cualquier mesa**. | **Crítica** |
| 2 | Los QR de prueba (`QR-mesa-1/2/3.png`, 28/10) se firmaron con esa llave pública. **No sirven para imprimir los definitivos.** | **Crítica** (si ya los mandaron a imprimir) |
| 3 | El pedido de la mesa **no pasa por el servidor**: el celular arma un mensaje de WhatsApp con «MESA 1» y lo envía al número del negocio. El número de mesa es solo texto; el QR únicamente protege «Llamar al mesero» y «reclamar la mesa». | Alta |
| 4 | La llave de cada QR es **permanente**: quien la vio una vez (foto, historial del navegador, enlace reenviado) puede volver a reclamar esa mesa desde su casa. «Liberar» saca al dispositivo, pero si vuelve a escanear el bloqueo se levanta. | Alta |
| 5 | Sesión de la barra: usuario y contraseña **únicos y compartidos**, token de 12 h guardado en `localStorage`, sin cierre de sesión en el servidor (un celular perdido sigue entrando hasta 12 h), sin registro de quién hizo qué. Lo bueno: compara en tiempo constante y bloquea 5 intentos por IP cada 10 min. | Media/Alta |
| 6 | No hay cabeceras de seguridad (`_headers`). | Media |

**Regla de oro:** primero se rotan los secretos, después se generan e imprimen los QR. Imprimir antes = reimprimir.

---

## 1. QR sin dominio todavía

La llave del QR **no depende del dominio** (es `HMAC(QR_SECRET, mesa)`); solo el enlace que lleva el QR incluye el servidor. Hay tres caminos:

### A. Subdominio de `elcoctelazo.com` — DESCARTADO (13/11/2026)
- El Coctelazo Provenza es un negocio aparte de El Coctelazo: no deben compartir dominio ni cuenta de datos. Esta opción ya no aplica.

### B. Imprimir ya con `…workers.dev`
- Funciona hoy. Riesgos: URL fea que parece sospechosa y depende de la cuenta personal.
- Mitigación: dejar vivo `workers.dev` y, cuando exista el dominio, hacer que el Worker **redirija** (301) todo lo que entre por `workers.dev` al dominio nuevo conservando `?m=…&k=…`. Los QR viejos siguen sirviendo.

### C. Dominio propio nuevo para Provenza (RECOMENDADO desde el 13/11/2026)
- Disponibles el 13/11/2026 (consulta RDAP, a confirmar al comprar): elcoctelazoprovenza.com, coctelazoprovenza.com, coctelazoyperritos.com, perritosgourmetprovenza.com, provenzagourmet.com, perritosprovenza.com.
- El dominio debe comprarse en la MISMA cuenta de Cloudflare donde viva el Worker de Provenza (cuenta del dueño del negocio de Provenza).
- Cloudflare Registrar, ≈ USD 10 al año, minutos. No imprimir hasta tenerlo (o usar la redirección de B).

### Qué debe llevar el QR impreso
- El QR + la **dirección corta visible** debajo («provenza.elcoctelazo.com»): así el cliente puede comprobar que no es un QR pegado encima (estafa de «quishing»).
- Material resistente (acrílico/laminado) **fijo a la mesa**, no suelto. Que el mesero lo revise al abrir (lista de chequeo).
- Número de mesa grande. Cantidad de mesas: por definir (se pueden generar más después con el mismo secreto).

### Orden recomendado
1. Rotar secretos (sección 3, T0). 2. Decidir A, B o C. 3. Generar los QR en lote con la plantilla actual. 4. Probar 2 celulares distintos por mesa. 5. Mandar a imprimir.

---

## 2. Seguridad de las mesas (que no se metan «a la mesa 1» a hacer pedidos)

### A quién nos defendemos
a) Alguien que **no está en el local** y reclama/ocupa la mesa 1 para bloquear o molestar. b) Un cliente que **se llevó el enlace** y lo reutiliza. c) Un QR falso **pegado encima** del real. d) Bots que saturan `/api`. e) **Pedidos falsos por WhatsApp** (el número del negocio es público).

### Capas propuestas (de menor a mayor esfuerzo)
1. **Llaves secretas nuevas y guardadas como secreto de Cloudflare** (sección 3, T0). Sin esto nada de lo demás sirve.
2. **Aprobación de la barra en el primer escaneo.** El celular que escanea queda «pendiente»: puede ver la carta, pero no llamar ni enviar. En el panel de la barra aparece «Mesa 1 quiere pedir · Aprobar / Rechazar», igual que hoy aparecen los llamados. El mesero **ve a la persona sentada** y toca Aprobar. Quien está en su casa nunca pasa de «pendiente». Fricción baja: un toque del personal, ninguna para el cliente.
3. **Bloquear, no solo liberar.** Hoy «Liberar» se deshace con un nuevo escaneo. Se añade **«Bloquear dispositivo»** (por identificador del celular y por IP, 24 h o permanente) que el re-escaneo **no** puede levantar.
4. **Cerrar la mesa al cobrar.** La barra toca «Cerrar mesa» y ese celular pierde el acceso al instante (hoy tarda hasta 30 min sin señal). Además, un **tope de horas** por sesión (p. ej. 4 h) aunque siga dando señales.
5. **Rotar la llave de una sola mesa** (contador por mesa en el servidor): si hay abuso en la mesa 1, se reimprime solo ese QR. Las demás siguen valiendo.
6. **Límites y captcha:** límite de peticiones por IP/dispositivo en `/api/mesa` y `/api/llamar`, y Cloudflare **Turnstile** (captcha gratuito y casi invisible) al reclamar una mesa o tras varios intentos.
7. **Pedidos al servidor, no por WhatsApp** (el cambio que de verdad cierra el problema). El pedido viaja a `/api/pedido` con la sesión **aprobada** de la mesa y aparece en un panel **«Pedidos»** de la barra con sonido. El servidor valida mesa y precios; el cliente ve el estado (recibido → preparando → listo). Los mensajes falsos de WhatsApp dejan de importar porque la barra solo atiende lo que está en el panel. Costo: más desarrollo y que haya **una tablet/celular fijo en la barra** mirando el panel.
8. **Geolocalización (radio ~100 m):** solo como señal de riesgo, **no recomendada como barrera única** (se puede falsear, pide permiso y asusta a algunos clientes).

### Qué cubre cada capa
| Amenaza | Capas que la frenan |
|---|---|
| a) Ocupar/bloquear mesa desde fuera | 2, 3, 6 |
| b) Reutilizar un enlace | 2, 4, 5 |
| c) QR falso pegado encima | dominio claro + URL visible + QR fijo y revisado (sección 1) |
| d) Bots | 6 |
| e) Pedidos falsos por WhatsApp | 7 |

---

## 3. Seguridad del inicio de sesión de la barra

### T0 — inmediato (antes de imprimir nada)
- Crear **valores nuevos y largos** (de un gestor de contraseñas) para `ADMIN_USER`, `ADMIN_PASS`, `SESSION_SECRET` y `QR_SECRET`, y cargarlos como **Secretos en Cloudflare**. Borrar `EJEMPLO` del código.
- **Rotar, no solo borrar:** los valores actuales quedan para siempre en el historial público de git, así que están quemados. Considerar pasar el repositorio a **privado** (Cloudflare puede conectarse a repos privados).
- Efecto: hay que **regenerar los QR** (los de prueba dejan de valer). Mejor ahora que con 40 mesas impresas.

### T1 — cuentas por persona
Dueño + meseros, cada uno con su usuario y clave/PIN largo, guardada con hash (PBKDF2) en el servidor. Roles: *dueño* (libera, bloquea, crea y quita cuentas, ve la bitácora) y *mesero* (atiende llamados y pedidos). **Bitácora:** quién, qué, cuándo, desde qué IP.

### T2 — sesión más segura
Cookie **HttpOnly + Secure + SameSite=Strict** (en vez de `localStorage`, que un script malicioso podría leer), duración por turno (8 h), **cerrar sesión** que invalida en el servidor y botón **«cerrar todas las sesiones»** para un celular perdido. Cambiar la clave invalida las sesiones abiertas.

### T3 — freno a la fuerza bruta
Bloqueo por cuenta **y** por IP con espera creciente (hoy solo por IP y fija), Turnstile desde el 3.er fallo y aviso al dueño por intentos sospechosos.

### T4 — segundo factor para el dueño
Código de 6 dígitos (TOTP, tipo Google Authenticator) para la cuenta del dueño, **o** poner la administración detrás de **Cloudflare Access** (entrar con Google/correo, gratis hasta 50 personas) y no tener contraseñas en el código.

### T5 — cabeceras (`_headers`)
`Content-Security-Policy`, `frame-ancestors`, `nosniff`, `Referrer-Policy` y `Permissions-Policy: camera=(self), geolocation=(self)` (la cámara hace falta para escanear el QR y la ubicación para los domicilios). HSTS lo pone Cloudflare al tener dominio.

---

## 4. Fases y estimación

| Fase | Qué incluye | Esfuerzo |
|---|---|---|
| **0** | Rotar secretos, decidir dominio/subdominio, Worker en la cuenta correcta, generar QR en lote, prueba en 2 celulares | 1–2 h |
| **1** | Mesa: aprobación en el primer escaneo, bloqueo, cerrar mesa, rotar llave por mesa, tope de horas, límites + Turnstile, pruebas | ~1 día |
| **2** | Barra: cuentas por persona, cookie segura, cerrar sesiones, bitácora, TOTP del dueño, `_headers` | ~1 día |
| **3** | Pedidos al servidor: panel «Pedidos» con sonido, estados para el cliente, quitar WhatsApp en mesa | 2–3 días |

Pruebas: ampliar `test/api.test.mjs` (hoy 15 pruebas) con ataques simulados (reusar enlace, mesa pendiente, bloqueo, fuerza bruta, sesión revocada) antes de cada publicación.

---

## 5. Lo que necesito que decidas

1. **Dominio de los QR:** dominio propio de Provenza (cuál nombre) y en qué cuenta de Cloudflare queda.
2. **Los QR que ya mandaron a hacer:** ¿con qué enlace y con qué llave se hicieron? Si salieron de los de prueba hay que **detener la impresión** hasta la fase 0.
3. **Cuántas mesas** habrá.
4. **Aprobación del mesero** en el primer escaneo: ¿sí?
5. **Pedidos de mesa:** ¿siguen por WhatsApp (más simple) o pasan al panel de la barra (más seguro, más trabajo)?
6. **Quién entra a la barra:** cuántas personas y quién es el dueño.
7. **Repositorio:** ¿lo pasamos a privado?
