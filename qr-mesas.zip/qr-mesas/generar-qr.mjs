// Generador de los QR de las mesas de El Coctelazo Provenza.
//
//   node qr-mesas/generar-qr.mjs                      → abre http://localhost:8863 (hace falta internet: carga la librería de QR)
//
// Qué hace: sirve la página `generar.html` (en esta misma carpeta), que dibuja una tarjeta por mesa con su QR y la guarda en
// `qr-mesas/nuevos/` como PNG. La llave de cada mesa se calcula con QR_SECRET (leído de SECRETOS-NUEVOS-CLOUDFLARE.txt, que NO se
// sube a GitHub) y el servidor la vuelve a calcular con el código del Worker para comprobar que el enlace del QR es el correcto.
//
// Ajustes por variable de entorno:  DOMINIO (por defecto https://elcoctelazoprovenza.com)   MESAS (por defecto 15)   PORT (8863)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mesaToken } from '../worker/index.js';

const AQUI = path.dirname(fileURLToPath(import.meta.url));
const RAIZ = path.resolve(AQUI, '..');
const SALIDA = path.join(AQUI, 'nuevos');
const PORT = Number(process.env.PORT || 8863);
const DOMINIO = (process.env.DOMINIO || 'https://elcoctelazoprovenza.com').replace(/\/+$/, '');
const MESAS = Number(process.env.MESAS || 15);

function leerSecreto() {
  const txt = fs.readFileSync(path.join(AQUI, 'SECRETOS-NUEVOS-CLOUDFLARE.txt'), 'utf8');
  const m = /^QR_SECRET\s*=\s*(\S+)/m.exec(txt);
  if (!m) throw new Error('No encontré QR_SECRET en SECRETOS-NUEVOS-CLOUDFLARE.txt');
  return m[1];
}
const QR_SECRET = leerSecreto();
fs.mkdirSync(SALIDA, { recursive: true });

const enlaces = {};   // mesa → enlace comprobado
http.createServer(async (q, r) => {
  const u = new URL(q.url, 'http://localhost');
  const local = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(q.socket.remoteAddress);
  if (!local) { r.writeHead(403); return r.end(); }
  const send = (code, type, body) => { r.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); r.end(body); };
  if (q.method === 'GET' && u.pathname === '/') return send(200, 'text/html; charset=utf-8', fs.readFileSync(path.join(AQUI, 'generar.html')));
  if (q.method === 'GET' && u.pathname === '/config') return send(200, 'application/json', JSON.stringify({ dominio: DOMINIO, mesas: MESAS }));
  if (q.method === 'GET' && u.pathname === '/jsQR.js') return send(200, 'text/javascript; charset=utf-8', fs.readFileSync(path.join(RAIZ, 'jsQR.js')));   // el lector de QR del proyecto, para comprobar lo generado
  if (q.method === 'GET' && u.pathname === '/logo.webp') return send(200, 'image/webp', fs.readFileSync(path.join(RAIZ, 'img', 'logo-by-perritos.webp')));
  // la página pide la llave de cada mesa; el servidor es quien la calcula con el mismo código que usa el Worker
  if (q.method === 'GET' && u.pathname === '/enlace') {
    const n = Number(u.searchParams.get('m'));
    if (!Number.isInteger(n) || n < 1 || n > 99) return send(400, 'text/plain', 'mesa fuera de rango');
    const url = `${DOMINIO}/?m=${n}&k=${await mesaToken(QR_SECRET, n)}`;
    enlaces[n] = url;
    return send(200, 'text/plain; charset=utf-8', url);
  }
  if (q.method === 'POST' && u.pathname === '/guardar') {
    const nombre = (u.searchParams.get('name') || '').replace(/[^\w.\-]/g, '');
    if (!/\.png$/.test(nombre)) return send(400, 'text/plain', 'nombre no válido');
    const chunks = []; for await (const c of q) chunks.push(c);
    const buf = Buffer.from(Buffer.concat(chunks).toString().split(',')[1], 'base64');
    fs.writeFileSync(path.join(SALIDA, nombre), buf);
    return send(200, 'text/plain', 'guardado ' + nombre + ' ' + buf.length);
  }
  if (q.method === 'POST' && u.pathname === '/fin') {   // lista de enlaces para guardar junto a los PNG
    const lineas = Object.keys(enlaces).map(Number).sort((a, b) => a - b).map(n => `Mesa ${n}: ${enlaces[n]}`);
    fs.writeFileSync(path.join(SALIDA, 'ENLACES-DE-LAS-MESAS.txt'), `Enlaces que lleva el QR de cada mesa (NO compartir: quien tenga un enlace puede reclamar esa mesa)\nGenerados ${new Date().toLocaleString('es-CO')}\n\n` + lineas.join('\n') + '\n');
    return send(200, 'text/plain', 'ok ' + lineas.length);
  }
  send(404, 'text/plain', 'no encontrado');
}).listen(PORT, '127.0.0.1', () => console.log(`Generador de QR: http://localhost:${PORT}   (dominio ${DOMINIO}, ${MESAS} mesas, salida ${SALIDA})`));
